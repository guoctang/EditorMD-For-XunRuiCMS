<?php

return [

    'type' => 'app',
    'author' => 'guoctang',
    'name' => 'Editor.md 编辑器',
    'icon' => 'fa fa-edit',

];