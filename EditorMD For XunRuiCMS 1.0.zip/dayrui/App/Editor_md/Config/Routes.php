<?php

// 加载主程序的路由
require COREPATH.'Config/Routes.php';