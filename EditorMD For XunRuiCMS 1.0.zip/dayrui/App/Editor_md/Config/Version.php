<?php

return [

    'vip' => '0',
    'cms' => '4.6.3',
    'version' => '1.0',

];
