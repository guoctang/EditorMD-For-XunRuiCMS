<?php

/**
 * 可用字段
 * id  插件目录名::文件名称
 * name 显示名称
 */

return [
    [
        'id' => 'Editor_md::Editor_md', // 插件目录名::文件名称
        'name' => 'Editor.md编辑器',
        'used' => '',
        'namespace' => '',
    ],
];